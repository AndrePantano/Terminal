<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//offline
$config['protocol'] = 'smtp';
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['wordwrap'] = TRUE;
$config['smtp_host'] = 'ssl://smtp.gmail.com';
$config['smtp_port'] = '465';
$config['smtp_user'] = 'cdvnoreply@gmail.com';
$config['smtp_pass'] = 'admin.cdv';
