<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">    
<script src="<?php echo base_url('assets/jquery/jquery.min.js')?>" ></script>  
<link href="<?php echo base_url('assets/bootstrap/css/bootstrap.css')?>" rel="stylesheet">
<link href="<?php echo base_url('assets/bootstrap/css/andre.css')?>" rel="stylesheet">
<link href="<?php echo base_url('assets/font-awesome/css/font-awesome.css')?>" rel="stylesheet">  
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.js')?>"></script>
<link rel="shortcut icon" type="image/jpg" href="<?php echo base_url('assets/images/ico.jpg')?>" />
