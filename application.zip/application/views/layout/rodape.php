 <br/><br/>
 <div class="row">
    <div class="col-sm-12 text-center text-muted">      
         <hr></hr>
         <p>Terminal &copy; <?=date("Y")?></p>     
    </div>
  </div>