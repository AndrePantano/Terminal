<div class="row">
	<div class="col-sm-12">			
		<h1><i class="<?=$main['icon']?>"></i> <?=$main['name']?></h1>
	</div>
</div>